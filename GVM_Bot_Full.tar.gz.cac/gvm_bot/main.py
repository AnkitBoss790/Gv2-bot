import discord
from discord.ext import commands
import json
import os
import psutil
import asyncio
from datetime import datetime
import uuid
import subprocess
import signal
import socket
import random
from vps_manager import VPSManager

# Load configuration
with open('config.json', 'r') as f:
    config = json.load(f)

# Bot setup
intents = discord.Intents.default()
intents.message_content = True
intents.members = True

bot = commands.Bot(command_prefix=config['bot_settings']['prefix'], intents=intents, help_command=None)

# VPS Storage
VPS_FILE = 'vps_data.json'

def load_vps_data():
    if os.path.exists(VPS_FILE):
        with open(VPS_FILE, 'r') as f:
            return json.load(f)
    return {}

def save_vps_data(data):
    with open(VPS_FILE, 'w') as f:
        json.dump(data, f, indent=4)

vps_storage = load_vps_data()
vps_manager = VPSManager()

def is_admin(user_id):
    return user_id in config['admin_ids']

def create_embed(title, description, color=0x00ff00):
    embed = discord.Embed(title=title, description=description, color=color, timestamp=datetime.utcnow())
    embed.set_footer(text=f"Made by {config['bot_settings']['developer']}")
    return embed

def create_progress_bar(current, maximum, length=20):
    """Create a text-based progress bar"""
    if maximum == 0:
        return "█" * length
    
    filled = int((current / maximum) * length)
    filled = min(filled, length)
    
    bar = "█" * filled + "░" * (length - filled)
    return f"`{bar}`"

@bot.event
async def on_ready():
    print(f'╔════════════════════════════════════╗')
    print(f'║   GVM Bot Successfully Started!    ║')
    print(f'╚════════════════════════════════════╝')
    print(f'Bot Name: {bot.user.name}')
    print(f'Bot ID: {bot.user.id}')
    print(f'Developer: {config["bot_settings"]["developer"]}')
    print(f'Version: {config["bot_settings"]["version"]}')
    print(f'Connected to {len(bot.guilds)} server(s)')
    
    # Set bot status
    await bot.change_presence(
        activity=discord.Activity(
            type=discord.ActivityType.watching,
            name=f"By {config['bot_settings']['developer']} | /help"
        )
    )

@bot.command(name='help')
async def help_command(ctx):
    """Display all available commands"""
    embed = discord.Embed(
        title="🤖 GVM Bot - Command List",
        description=f"**VPS Management Bot by {config['bot_settings']['developer']}**\n\n",
        color=0x3498db,
        timestamp=datetime.utcnow()
    )
    
    # Admin Commands
    admin_cmds = """
    **📋 Admin Commands:**
    `/createvps <ram> <cpu> <disk> <@user>` - Create a dedicated VPS for user
    `/deletevps <vps_id>` - Delete a VPS permanently
    `/listall` - Show all VPS in the system
    `/addadmin <user_id>` - Add a new admin
    `/removeadmin <user_id>` - Remove an admin
    `/execvps <vps_id> <command>` - Execute command in VPS
    """
    
    # User Commands
    user_cmds = """
    **👤 User Commands:**
    `/listvps` - Show your own VPS
    `/vpsinfo <vps_id>` - Get detailed info about your VPS
    `/startvps <vps_id>` - Start your VPS with dedicated resources
    `/stopvps <vps_id>` - Stop your VPS and release resources
    `/restartvps <vps_id>` - Restart your VPS
    `/vpsresources <vps_id>` - Check VPS resource usage
    `/sshinfo <vps_id>` - Get SSH connection details
    `/portforward <vps_id> <local> <remote>` - Setup port forwarding
    `/vpsbackup <vps_id>` - Backup your VPS data
    """
    
    # General Commands
    general_cmds = """
    **ℹ️ General Commands:**
    `/botinfo` - Show bot information
    `/help` - Show this help menu
    `/ping` - Check bot latency
    `/download` - Get bot download link
    """
    
    embed.add_field(name="\u200b", value=admin_cmds, inline=False)
    embed.add_field(name="\u200b", value=user_cmds, inline=False)
    embed.add_field(name="\u200b", value=general_cmds, inline=False)
    embed.set_footer(text=f"Made by {config['bot_settings']['developer']}")
    
    await ctx.send(embed=embed)

@bot.command(name='createvps')
async def create_vps(ctx, ram: int, cpu: int, disk: int, user: discord.Member):
    """Admin only: Create a VPS for a user with dedicated resources"""
    if not is_admin(ctx.author.id):
        embed = create_embed("❌ Access Denied", "Only admins can use this command!", 0xff0000)
        await ctx.send(embed=embed)
        return
    
    # Processing message
    processing_msg = await ctx.send(embed=create_embed(
        "⏳ Processing VPS Creation",
        "```\n🔄 Initializing VPS creation...\n📦 Allocating dedicated resources...\n🖥️ Setting up virtual environment...\n🔧 Configuring system parameters...\n✅ Finalizing setup...\n```",
        0xffff00
    ))
    
    await asyncio.sleep(2)  # Simulate processing
    
    vps_id = str(uuid.uuid4())[:8]
    
    # Create dedicated VPS using VPS Manager
    ssh_port = random.randint(10000, 60000)
    
    try:
        vps_info = vps_manager.create_vps(vps_id, ram, cpu, disk)
        
        vps_data = {
            'id': vps_id,
            'owner_id': user.id,
            'owner_name': str(user),
            'ram': ram,
            'cpu': cpu,
            'disk': disk,
            'status': 'stopped',
            'created_at': datetime.utcnow().isoformat(),
            'ssh_port': ssh_port,
            'ssh_password': str(uuid.uuid4())[:12],
            'process_id': None,
            'vps_path': vps_info['path']
        }
        
        vps_storage[vps_id] = vps_data
        save_vps_data(vps_storage)
        
        embed = discord.Embed(
            title="✅ Dedicated VPS Created Successfully!",
            description=f"VPS with dedicated resources has been created for {user.mention}",
            color=0x00ff00,
            timestamp=datetime.utcnow()
        )
        embed.add_field(name="🆔 VPS ID", value=f"`{vps_id}`", inline=True)
        embed.add_field(name="👤 Owner", value=user.mention, inline=True)
        embed.add_field(name="🔌 SSH Port", value=f"`{ssh_port}`", inline=True)
        embed.add_field(name="💾 Dedicated RAM", value=f"`{ram} GB`", inline=True)
        embed.add_field(name="⚡ CPU Cores", value=f"`{cpu} Cores`", inline=True)
        embed.add_field(name="💿 Disk Space", value=f"`{disk} GB`", inline=True)
        embed.add_field(name="📊 Status", value="🔴 Stopped (Use /startvps to start)", inline=True)
        embed.add_field(name="🔑 SSH Password", value=f"`{vps_data['ssh_password']}`", inline=False)
        embed.add_field(
            name="📡 SSH Connection",
            value=f"`ssh root@YOUR_SERVER_IP -p {ssh_port}`",
            inline=False
        )
        embed.add_field(
            name="💡 Next Steps",
            value="• Use `/startvps {vps_id}` to start the VPS\n• Use `/sshinfo {vps_id}` for connection details",
            inline=False
        )
        embed.set_footer(text=f"Made by {config['bot_settings']['developer']}")
        
        await processing_msg.edit(embed=embed)
        
    except Exception as e:
        embed = create_embed("❌ Error", f"Failed to create VPS: {str(e)}", 0xff0000)
        await processing_msg.edit(embed=embed)

@bot.command(name='deletevps')
async def delete_vps(ctx, vps_id: str):
    """Admin only: Delete a VPS"""
    if not is_admin(ctx.author.id):
        embed = create_embed("❌ Access Denied", "Only admins can use this command!", 0xff0000)
        await ctx.send(embed=embed)
        return
    
    if vps_id not in vps_storage:
        embed = create_embed("❌ Error", f"VPS with ID `{vps_id}` not found!", 0xff0000)
        await ctx.send(embed=embed)
        return
    
    vps_data = vps_storage[vps_id]
    
    # Stop VPS if running
    if vps_data.get('process_id'):
        vps_manager.stop_vps(vps_data['process_id'])
    
    # Delete VPS data
    vps_manager.delete_vps(vps_id)
    
    del vps_storage[vps_id]
    save_vps_data(vps_storage)
    
    embed = create_embed(
        "✅ VPS Deleted",
        f"VPS `{vps_id}` owned by <@{vps_data['owner_id']}> has been deleted successfully!",
        0x00ff00
    )
    await ctx.send(embed=embed)

@bot.command(name='listall')
async def list_all(ctx):
    """Admin only: List all VPS in the system"""
    if not is_admin(ctx.author.id):
        embed = create_embed("❌ Access Denied", "Only admins can use this command!", 0xff0000)
        await ctx.send(embed=embed)
        return
    
    if not vps_storage:
        embed = create_embed("📋 All VPS List", "No VPS created yet!", 0xffff00)
        await ctx.send(embed=embed)
        return
    
    embed = discord.Embed(
        title="📋 All VPS List",
        description=f"Total VPS: **{len(vps_storage)}**\n\n",
        color=0x3498db,
        timestamp=datetime.utcnow()
    )
    
    for vps_id, vps in vps_storage.items():
        status_emoji = "🟢" if vps['status'] == 'running' else "🔴"
        vps_info = f"""
        **ID:** `{vps_id}`
        **Owner:** <@{vps['owner_id']}>
        **SSH Port:** `{vps.get('ssh_port', 'N/A')}`
        **Resources:** {vps['ram']}GB RAM | {vps['cpu']} CPU | {vps['disk']}GB Disk
        **Status:** {status_emoji} {vps['status'].capitalize()}
        """
        embed.add_field(name=f"VPS - {vps_id}", value=vps_info, inline=False)
    
    embed.set_footer(text=f"Made by {config['bot_settings']['developer']}")
    await ctx.send(embed=embed)

@bot.command(name='listvps')
async def list_vps(ctx):
    """Show your own VPS"""
    user_vps = {k: v for k, v in vps_storage.items() if v['owner_id'] == ctx.author.id}
    
    if not user_vps:
        embed = create_embed("📋 Your VPS List", "You don't have any VPS yet!", 0xffff00)
        await ctx.send(embed=embed)
        return
    
    embed = discord.Embed(
        title="📋 Your VPS List",
        description=f"Total VPS: **{len(user_vps)}**\n\n",
        color=0x3498db,
        timestamp=datetime.utcnow()
    )
    
    for vps_id, vps in user_vps.items():
        status_emoji = "🟢" if vps['status'] == 'running' else "🔴"
        vps_info = f"""
        **ID:** `{vps_id}`
        **SSH Port:** `{vps.get('ssh_port', 'N/A')}`
        **Resources:** {vps['ram']}GB RAM | {vps['cpu']} CPU | {vps['disk']}GB Disk
        **Status:** {status_emoji} {vps['status'].capitalize()}
        """
        embed.add_field(name=f"VPS - {vps_id}", value=vps_info, inline=False)
    
    embed.set_footer(text=f"Made by {config['bot_settings']['developer']}")
    await ctx.send(embed=embed)

@bot.command(name='vpsinfo')
async def vps_info(ctx, vps_id: str):
    """Get detailed information about a VPS"""
    if vps_id not in vps_storage:
        embed = create_embed("❌ Error", f"VPS with ID `{vps_id}` not found!", 0xff0000)
        await ctx.send(embed=embed)
        return
    
    vps = vps_storage[vps_id]
    
    if vps['owner_id'] != ctx.author.id and not is_admin(ctx.author.id):
        embed = create_embed("❌ Access Denied", "You don't have permission to view this VPS!", 0xff0000)
        await ctx.send(embed=embed)
        return
    
    status_emoji = "🟢" if vps['status'] == 'running' else "🔴"
    
    embed = discord.Embed(
        title=f"🖥️ VPS Information - {vps_id}",
        description="Detailed VPS Configuration",
        color=0x3498db,
        timestamp=datetime.utcnow()
    )
    embed.add_field(name="🆔 VPS ID", value=f"`{vps_id}`", inline=True)
    embed.add_field(name="👤 Owner", value=f"<@{vps['owner_id']}>", inline=True)
    embed.add_field(name="🔌 SSH Port", value=f"`{vps.get('ssh_port', 'N/A')}`", inline=True)
    embed.add_field(name="💾 Dedicated RAM", value=f"`{vps['ram']} GB`", inline=True)
    embed.add_field(name="⚡ CPU Cores", value=f"`{vps['cpu']} Cores`", inline=True)
    embed.add_field(name="💿 Disk Space", value=f"`{vps['disk']} GB`", inline=True)
    embed.add_field(name="📊 Status", value=f"{status_emoji} {vps['status'].capitalize()}", inline=True)
    embed.add_field(name="📅 Created At", value=vps['created_at'][:10], inline=True)
    
    if vps.get('ssh_password'):
        embed.add_field(name="🔑 SSH Password", value=f"`{vps['ssh_password']}`", inline=False)
    if vps.get('ssh_port'):
        embed.add_field(name="📡 SSH Connect", value=f"`ssh root@YOUR_SERVER_IP -p {vps['ssh_port']}`", inline=False)
    
    embed.set_footer(text=f"Made by {config['bot_settings']['developer']}")
    
    await ctx.send(embed=embed)

@bot.command(name='startvps')
async def start_vps(ctx, vps_id: str):
    """Start your VPS with dedicated resources"""
    if vps_id not in vps_storage:
        embed = create_embed("❌ Error", f"VPS with ID `{vps_id}` not found!", 0xff0000)
        await ctx.send(embed=embed)
        return
    
    vps = vps_storage[vps_id]
    
    if vps['owner_id'] != ctx.author.id and not is_admin(ctx.author.id):
        embed = create_embed("❌ Access Denied", "You don't have permission to control this VPS!", 0xff0000)
        await ctx.send(embed=embed)
        return
    
    if vps['status'] == 'running':
        embed = create_embed("⚠️ Warning", "VPS is already running!", 0xffff00)
        await ctx.send(embed=embed)
        return
    
    # Start VPS with resource limits
    processing = await ctx.send(embed=create_embed(
        "⏳ Starting VPS",
        "```\n🔄 Initializing VPS...\n💾 Allocating dedicated RAM...\n⚡ Assigning CPU cores...\n🔌 Starting SSH server...\n✅ VPS starting...\n```",
        0xffff00
    ))
    
    try:
        # Start VPS with dedicated resources
        pid = vps_manager.start_vps(vps_id, vps['ram'], vps['cpu'], vps['ssh_port'])
        
        vps['status'] = 'running'
        vps['process_id'] = pid
        save_vps_data(vps_storage)
        
        embed = create_embed(
            "✅ VPS Started Successfully!",
            f"VPS `{vps_id}` is now running with dedicated resources",
            0x00ff00
        )
        embed.add_field(name="💾 RAM Allocated", value=f"`{vps['ram']} GB`", inline=True)
        embed.add_field(name="⚡ CPU Cores", value=f"`{vps['cpu']} Cores`", inline=True)
        embed.add_field(name="💿 Disk Space", value=f"`{vps['disk']} GB`", inline=True)
        embed.add_field(name="🔌 SSH Port", value=f"`{vps['ssh_port']}`", inline=True)
        embed.add_field(name="🔑 Password", value=f"`{vps['ssh_password']}`", inline=True)
        embed.add_field(name="📊 Status", value="🟢 Running", inline=True)
        embed.add_field(
            name="📡 Connect",
            value=f"`ssh root@YOUR_SERVER_IP -p {vps['ssh_port']}`",
            inline=False
        )
        
        await processing.edit(embed=embed)
        
    except Exception as e:
        vps['status'] = 'stopped'
        save_vps_data(vps_storage)
        embed = create_embed("❌ Error", f"Failed to start VPS: {str(e)}", 0xff0000)
        await processing.edit(embed=embed)

@bot.command(name='stopvps')
async def stop_vps(ctx, vps_id: str):
    """Stop your VPS and release resources"""
    if vps_id not in vps_storage:
        embed = create_embed("❌ Error", f"VPS with ID `{vps_id}` not found!", 0xff0000)
        await ctx.send(embed=embed)
        return
    
    vps = vps_storage[vps_id]
    
    if vps['owner_id'] != ctx.author.id and not is_admin(ctx.author.id):
        embed = create_embed("❌ Access Denied", "You don't have permission to control this VPS!", 0xff0000)
        await ctx.send(embed=embed)
        return
    
    if vps['status'] == 'stopped':
        embed = create_embed("⚠️ Warning", "VPS is already stopped!", 0xffff00)
        await ctx.send(embed=embed)
        return
    
    processing = await ctx.send(embed=create_embed("⏳ Stopping VPS", "Releasing resources...", 0xffff00))
    
    try:
        # Kill the process if it exists
        if vps.get('process_id'):
            vps_manager.stop_vps(vps['process_id'])
        
        vps['status'] = 'stopped'
        vps['process_id'] = None
        save_vps_data(vps_storage)
        
        embed = create_embed(
            "✅ VPS Stopped",
            f"VPS `{vps_id}` has been stopped and resources released!",
            0x00ff00
        )
        await processing.edit(embed=embed)
        
    except Exception as e:
        embed = create_embed("❌ Error", f"Failed to stop VPS: {str(e)}", 0xff0000)
        await processing.edit(embed=embed)

@bot.command(name='restartvps')
async def restart_vps(ctx, vps_id: str):
    """Restart your VPS"""
    if vps_id not in vps_storage:
        embed = create_embed("❌ Error", f"VPS with ID `{vps_id}` not found!", 0xff0000)
        await ctx.send(embed=embed)
        return
    
    vps = vps_storage[vps_id]
    
    if vps['owner_id'] != ctx.author.id and not is_admin(ctx.author.id):
        embed = create_embed("❌ Access Denied", "You don't have permission to control this VPS!", 0xff0000)
        await ctx.send(embed=embed)
        return
    
    processing = await ctx.send(embed=create_embed("⏳ Restarting VPS", "Please wait...", 0xffff00))
    
    try:
        # Stop if running
        if vps.get('process_id'):
            vps_manager.stop_vps(vps['process_id'])
        
        await asyncio.sleep(2)
        
        # Start again
        pid = vps_manager.start_vps(vps_id, vps['ram'], vps['cpu'], vps['ssh_port'])
        
        vps['status'] = 'running'
        vps['process_id'] = pid
        save_vps_data(vps_storage)
        
        embed = create_embed("✅ VPS Restarted", f"VPS `{vps_id}` has been restarted successfully!", 0x00ff00)
        await processing.edit(embed=embed)
        
    except Exception as e:
        embed = create_embed("❌ Error", f"Failed to restart VPS: {str(e)}", 0xff0000)
        await processing.edit(embed=embed)

@bot.command(name='vpsresources')
async def vps_resources(ctx, vps_id: str):
    """Check VPS resource usage"""
    if vps_id not in vps_storage:
        embed = create_embed("❌ Error", f"VPS with ID `{vps_id}` not found!", 0xff0000)
        await ctx.send(embed=embed)
        return
    
    vps = vps_storage[vps_id]
    
    if vps['owner_id'] != ctx.author.id and not is_admin(ctx.author.id):
        embed = create_embed("❌ Access Denied", "You don't have permission to view this VPS!", 0xff0000)
        await ctx.send(embed=embed)
        return
    
    # Get resource stats
    stats = vps_manager.get_vps_stats(vps_id, vps.get('process_id'))
    
    # Calculate percentages
    cpu_usage = stats['cpu_percent']
    ram_used = stats['memory_mb']
    ram_limit = vps['ram'] * 1024
    ram_percent = (ram_used / ram_limit * 100) if ram_limit > 0 else 0
    
    disk_used = stats['disk_used_mb']
    disk_limit = vps['disk'] * 1024
    disk_percent = (disk_used / disk_limit * 100) if disk_limit > 0 else 0
    
    embed = discord.Embed(
        title=f"📊 VPS Resources - {vps_id}",
        description="Current Resource Usage",
        color=0x3498db,
        timestamp=datetime.utcnow()
    )
    
    # CPU Usage Bar
    cpu_bar = create_progress_bar(cpu_usage, 100)
    embed.add_field(
        name=f"⚡ CPU Usage: {cpu_usage:.1f}%",
        value=f"{cpu_bar}\nLimit: {vps['cpu']} Cores",
        inline=False
    )
    
    # RAM Usage Bar
    ram_bar = create_progress_bar(ram_percent, 100)
    embed.add_field(
        name=f"💾 RAM Usage: {ram_percent:.1f}%",
        value=f"{ram_bar}\n{ram_used:.0f}MB / {ram_limit:.0f}MB",
        inline=False
    )
    
    # Disk Usage Bar
    disk_bar = create_progress_bar(disk_percent, 100)
    embed.add_field(
        name=f"💿 Disk Usage: {disk_percent:.1f}%",
        value=f"{disk_bar}\n{disk_used:.0f}MB / {disk_limit:.0f}MB",
        inline=False
    )
    
    status_emoji = "🟢" if vps['status'] == 'running' else "🔴"
    embed.add_field(name="📊 Status", value=f"{status_emoji} {vps['status'].capitalize()}", inline=True)
    
    embed.set_footer(text=f"Made by {config['bot_settings']['developer']}")
    await ctx.send(embed=embed)

@bot.command(name='sshinfo')
async def ssh_info(ctx, vps_id: str):
    """Get SSH connection details"""
    if vps_id not in vps_storage:
        embed = create_embed("❌ Error", f"VPS with ID `{vps_id}` not found!", 0xff0000)
        await ctx.send(embed=embed)
        return
    
    vps = vps_storage[vps_id]
    
    if vps['owner_id'] != ctx.author.id and not is_admin(ctx.author.id):
        embed = create_embed("❌ Access Denied", "You don't have permission to view this VPS!", 0xff0000)
        await ctx.send(embed=embed)
        return
    
    embed = discord.Embed(
        title=f"🔐 SSH Connection Info - {vps_id}",
        description="Use these credentials to connect to your VPS",
        color=0x9b59b6,
        timestamp=datetime.utcnow()
    )
    
    # Get server IP (you need to set this)
    server_ip = "YOUR_SERVER_IP"  # Replace with actual server IP
    
    ssh_command = f"ssh root@{server_ip} -p {vps.get('ssh_port', 'N/A')}"
    
    embed.add_field(name="🌐 Server IP", value=f"`{server_ip}`", inline=True)
    embed.add_field(name="🔌 SSH Port", value=f"`{vps.get('ssh_port', 'N/A')}`", inline=True)
    embed.add_field(name="👤 Username", value="`root`", inline=True)
    embed.add_field(name="🔑 Password", value=f"`{vps.get('ssh_password', 'N/A')}`", inline=False)
    embed.add_field(name="📡 SSH Command", value=f"`{ssh_command}`", inline=False)
    
    # Alternative: Netcat connection
    nc_command = f"nc {server_ip} {vps.get('ssh_port', 'N/A')}"
    embed.add_field(name="🔧 Alternative (Netcat)", value=f"`{nc_command}`", inline=False)
    
    # Port forwarding example
    pf_example = f"ssh -L 8080:localhost:8080 root@{server_ip} -p {vps.get('ssh_port', 'N/A')}"
    embed.add_field(name="🔀 Port Forwarding Example", value=f"`{pf_example}`", inline=False)
    
    embed.add_field(
        name="📝 Notes",
        value="• Make sure VPS is running before connecting\n• Use port forwarding for web services\n• Contact admin if you can't connect",
        inline=False
    )
    
    embed.set_footer(text=f"Made by {config['bot_settings']['developer']}")
    await ctx.send(embed=embed)

@bot.command(name='portforward')
async def port_forward(ctx, vps_id: str, local_port: int, remote_port: int):
    """Setup port forwarding for your VPS"""
    if vps_id not in vps_storage:
        embed = create_embed("❌ Error", f"VPS with ID `{vps_id}` not found!", 0xff0000)
        await ctx.send(embed=embed)
        return
    
    vps = vps_storage[vps_id]
    
    if vps['owner_id'] != ctx.author.id and not is_admin(ctx.author.id):
        embed = create_embed("❌ Access Denied", "You don't have permission to control this VPS!", 0xff0000)
        await ctx.send(embed=embed)
        return
    
    embed = discord.Embed(
        title=f"🔀 Port Forwarding Setup - {vps_id}",
        description="Configure port forwarding for your VPS",
        color=0x3498db,
        timestamp=datetime.utcnow()
    )
    
    server_ip = "YOUR_SERVER_IP"
    ssh_port = vps.get('ssh_port', 'N/A')
    
    # SSH Port Forwarding Command
    pf_command = f"ssh -L {local_port}:localhost:{remote_port} root@{server_ip} -p {ssh_port} -N"
    
    embed.add_field(name="📌 Local Port", value=f"`{local_port}`", inline=True)
    embed.add_field(name="📌 Remote Port", value=f"`{remote_port}`", inline=True)
    embed.add_field(name="🔌 SSH Port", value=f"`{ssh_port}`", inline=True)
    embed.add_field(name="📡 Command", value=f"```bash\n{pf_command}\n```", inline=False)
    
    embed.add_field(
        name="📝 Instructions",
        value=f"1. Run the command above in your terminal\n"
              f"2. Keep the terminal open\n"
              f"3. Access via `localhost:{local_port}`\n"
              f"4. Press Ctrl+C to stop forwarding",
        inline=False
    )
    
    embed.add_field(
        name="💡 Examples",
        value=f"• Web Server: Forward 8080 → 80\n"
              f"• Database: Forward 3307 → 3306\n"
              f"• SSH: Forward 2222 → 22",
        inline=False
    )
    
    embed.set_footer(text=f"Made by {config['bot_settings']['developer']}")
    await ctx.send(embed=embed)

@bot.command(name='vpsbackup')
async def vps_backup(ctx, vps_id: str):
    """Backup your VPS data"""
    if vps_id not in vps_storage:
        embed = create_embed("❌ Error", f"VPS with ID `{vps_id}` not found!", 0xff0000)
        await ctx.send(embed=embed)
        return
    
    vps = vps_storage[vps_id]
    
    if vps['owner_id'] != ctx.author.id and not is_admin(ctx.author.id):
        embed = create_embed("❌ Access Denied", "You don't have permission to backup this VPS!", 0xff0000)
        await ctx.send(embed=embed)
        return
    
    processing = await ctx.send(embed=create_embed("⏳ Creating Backup", "Backing up VPS data...", 0xffff00))
    
    try:
        import tarfile
        import time
        
        backup_name = f"vps_{vps_id}_backup_{int(time.time())}.tar.gz"
        backup_path = f"/tmp/{backup_name}"
        vps_path = f"/tmp/gvm_vps/{vps_id}"
        
        if os.path.exists(vps_path):
            with tarfile.open(backup_path, "w:gz") as tar:
                tar.add(vps_path, arcname=vps_id)
            
            # Get backup size
            backup_size = os.path.getsize(backup_path) / 1024 / 1024  # MB
            
            embed = create_embed(
                "✅ Backup Created",
                f"VPS `{vps_id}` has been backed up successfully!",
                0x00ff00
            )
            embed.add_field(name="📦 Backup File", value=f"`{backup_name}`", inline=True)
            embed.add_field(name="💾 Size", value=f"`{backup_size:.2f} MB`", inline=True)
            embed.add_field(name="📁 Location", value=f"`{backup_path}`", inline=False)
            embed.add_field(
                name="📝 Note",
                value="Download the backup file before it expires (24 hours)",
                inline=False
            )
            
            await processing.edit(embed=embed)
        else:
            embed = create_embed("❌ Error", "VPS data directory not found!", 0xff0000)
            await processing.edit(embed=embed)
            
    except Exception as e:
        embed = create_embed("❌ Error", f"Backup failed: {str(e)}", 0xff0000)
        await processing.edit(embed=embed)

@bot.command(name='execvps')
async def exec_vps(ctx, vps_id: str, *, command: str):
    """Admin only: Execute command in VPS"""
    if not is_admin(ctx.author.id):
        embed = create_embed("❌ Access Denied", "Only admins can use this command!", 0xff0000)
        await ctx.send(embed=embed)
        return
    
    if vps_id not in vps_storage:
        embed = create_embed("❌ Error", f"VPS with ID `{vps_id}` not found!", 0xff0000)
        await ctx.send(embed=embed)
        return
    
    processing = await ctx.send(embed=create_embed("⏳ Executing Command", f"Running: `{command}`", 0xffff00))
    
    try:
        result = vps_manager.execute_command(vps_id, command)
        
        # Limit output length
        if len(result) > 1900:
            result = result[:1900] + "\n... (output truncated)"
        
        embed = discord.Embed(
            title=f"✅ Command Executed - {vps_id}",
            description=f"**Command:** `{command}`",
            color=0x00ff00,
            timestamp=datetime.utcnow()
        )
        embed.add_field(name="📤 Output", value=f"```\n{result}\n```", inline=False)
        embed.set_footer(text=f"Made by {config['bot_settings']['developer']}")
        
        await processing.edit(embed=embed)
        
    except Exception as e:
        embed = create_embed("❌ Error", f"Failed to execute command: {str(e)}", 0xff0000)
        await processing.edit(embed=embed)

@bot.command(name='botinfo')
async def bot_info(ctx):
    """Show bot information"""
    # Get system stats
    cpu_percent = psutil.cpu_percent(interval=1)
    memory = psutil.virtual_memory()
    disk = psutil.disk_usage('/')
    
    embed = discord.Embed(
        title="🤖 GVM Bot Information",
        description="**Dedicated VPS Management Discord Bot**",
        color=0x9b59b6,
        timestamp=datetime.utcnow()
    )
    
    embed.add_field(name="👨‍💻 Developer", value=config['bot_settings']['developer'], inline=True)
    embed.add_field(name="📌 Version", value=config['bot_settings']['version'], inline=True)
    embed.add_field(name="🏓 Latency", value=f"{round(bot.latency * 1000)}ms", inline=True)
    embed.add_field(name="🖥️ Servers", value=str(len(bot.guilds)), inline=True)
    embed.add_field(name="👥 Users", value=str(len(bot.users)), inline=True)
    embed.add_field(name="📊 Total VPS", value=str(len(vps_storage)), inline=True)
    embed.add_field(name="⚡ CPU Usage", value=f"{cpu_percent}%", inline=True)
    embed.add_field(name="💾 RAM Usage", value=f"{memory.percent}%", inline=True)
    embed.add_field(name="💿 Disk Usage", value=f"{disk.percent}%", inline=True)
    embed.add_field(
        name="✨ Features",
        value="• Dedicated RAM allocation\n• CPU core assignment\n• Disk space limits\n• SSH access\n• Port forwarding",
        inline=False
    )
    
    embed.set_thumbnail(url=bot.user.avatar.url if bot.user.avatar else None)
    embed.set_footer(text=f"Made by {config['bot_settings']['developer']}")
    
    await ctx.send(embed=embed)

@bot.command(name='ping')
async def ping(ctx):
    """Check bot latency"""
    latency = round(bot.latency * 1000)
    embed = create_embed("🏓 Pong!", f"Bot Latency: **{latency}ms**", 0x00ff00)
    await ctx.send(embed=embed)

@bot.command(name='download')
async def download(ctx):
    """Get bot download link"""
    embed = discord.Embed(
        title="📥 Download GVM Bot",
        description="Get the latest version of GVM Bot source code",
        color=0x3498db,
        timestamp=datetime.utcnow()
    )
    
    embed.add_field(
        name="📦 Download Link",
        value="[Click here to download GVM Bot](https://github.com/PowerDev/gvm-bot)",
        inline=False
    )
    
    embed.add_field(
        name="📋 Included Files",
        value="• `main.py` - Main bot file\n"
              "• `vps_manager.py` - VPS management system\n"
              "• `config.json` - Configuration file\n"
              "• `requirements.txt` - Dependencies\n"
              "• `README.md` - Documentation\n"
              "• `SETUP_GUIDE.txt` - Setup instructions",
        inline=False
    )
    
    embed.add_field(
        name="✨ Features",
        value="• Dedicated VPS creation with RAM, CPU, Disk allocation\n"
              "• SSH server with port forwarding\n"
              "• Resource monitoring and management\n"
              "• Admin and user permission system\n"
              "• VPS backup functionality",
        inline=False
    )
    
    embed.add_field(
        name="🔧 Requirements",
        value="• Python 3.8+\n• discord.py\n• psutil",
        inline=False
    )
    
    embed.set_footer(text=f"Made by {config['bot_settings']['developer']}")
    await ctx.send(embed=embed)

@bot.command(name='addadmin')
async def add_admin(ctx, user_id: int):
    """Admin only: Add a new admin"""
    if not is_admin(ctx.author.id):
        embed = create_embed("❌ Access Denied", "Only admins can use this command!", 0xff0000)
        await ctx.send(embed=embed)
        return
    
    if user_id in config['admin_ids']:
        embed = create_embed("⚠️ Warning", "This user is already an admin!", 0xffff00)
        await ctx.send(embed=embed)
        return
    
    config['admin_ids'].append(user_id)
    with open('config.json', 'w') as f:
        json.dump(config, f, indent=2)
    
    embed = create_embed("✅ Admin Added", f"User <@{user_id}> has been added as admin!", 0x00ff00)
    await ctx.send(embed=embed)

@bot.command(name='removeadmin')
async def remove_admin(ctx, user_id: int):
    """Admin only: Remove an admin"""
    if not is_admin(ctx.author.id):
        embed = create_embed("❌ Access Denied", "Only admins can use this command!", 0xff0000)
        await ctx.send(embed=embed)
        return
    
    if user_id not in config['admin_ids']:
        embed = create_embed("⚠️ Warning", "This user is not an admin!", 0xffff00)
        await ctx.send(embed=embed)
        return
    
    config['admin_ids'].remove(user_id)
    with open('config.json', 'w') as f:
        json.dump(config, f, indent=2)
    
    embed = create_embed("✅ Admin Removed", f"User <@{user_id}> has been removed from admins!", 0x00ff00)
    await ctx.send(embed=embed)

# Error handling
@bot.event
async def on_command_error(ctx, error):
    if isinstance(error, commands.MissingRequiredArgument):
        embed = create_embed("❌ Missing Arguments", f"Please provide all required arguments!\nUse `/help` for command usage.", 0xff0000)
        await ctx.send(embed=embed)
    elif isinstance(error, commands.BadArgument):
        embed = create_embed("❌ Invalid Argument", f"Please provide valid arguments!\nUse `/help` for command usage.", 0xff0000)
        await ctx.send(embed=embed)
    elif isinstance(error, commands.CommandNotFound):
        pass  # Ignore command not found errors
    else:
        embed = create_embed("❌ Error", f"An error occurred: {str(error)}", 0xff0000)
        await ctx.send(embed=embed)

# Run the bot
if __name__ == "__main__":
    try:
        bot.run(config['token'])
    except Exception as e:
        print(f"Error starting bot: {e}")
        print("Please check your bot token in config.json")
