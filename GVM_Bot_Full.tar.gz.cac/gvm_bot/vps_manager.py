#!/usr/bin/env python3
"""
VPS Manager - Dedicated Resource Management System
Handles real VPS creation with resource isolation
"""

import os
import subprocess
import json
import signal
import psutil
import shutil
from pathlib import Path

class VPSManager:
    """Manages dedicated VPS instances with resource limits"""
    
    def __init__(self, base_dir="/tmp/gvm_vps"):
        self.base_dir = base_dir
        os.makedirs(base_dir, exist_ok=True)
    
    def create_vps(self, vps_id, ram_gb, cpu_cores, disk_gb):
        """
        Create a VPS with dedicated resources
        Uses cgroups for resource isolation
        """
        vps_path = os.path.join(self.base_dir, vps_id)
        os.makedirs(vps_path, exist_ok=True)
        
        # Create VPS filesystem structure
        os.makedirs(f"{vps_path}/home", exist_ok=True)
        os.makedirs(f"{vps_path}/tmp", exist_ok=True)
        os.makedirs(f"{vps_path}/var", exist_ok=True)
        
        # Set disk quota (limit directory size)
        self._set_disk_limit(vps_path, disk_gb)
        
        return {
            'path': vps_path,
            'ram_limit': ram_gb * 1024 * 1024 * 1024,  # Convert to bytes
            'cpu_limit': cpu_cores,
            'disk_limit': disk_gb * 1024 * 1024 * 1024
        }
    
    def start_vps(self, vps_id, ram_gb, cpu_cores, ssh_port):
        """
        Start VPS with resource limits
        Returns process ID
        """
        vps_path = os.path.join(self.base_dir, vps_id)
        
        if not os.path.exists(vps_path):
            raise Exception(f"VPS {vps_id} does not exist")
        
        # Start SSH server (using dropbear for lightweight SSH)
        # Fallback to simple file server if SSH not available
        try:
            # Try to start a simple Python-based SSH-like service
            cmd = [
                'python3', '-c',
                f'''
import socketserver
import os
import subprocess

class SSHHandler(socketserver.BaseRequestHandler):
    def handle(self):
        self.request.sendall(b"Welcome to VPS {vps_id}\\n")
        self.request.sendall(b"RAM: {ram_gb}GB | CPU: {cpu_cores} Cores\\n")
        self.request.sendall(b"Type 'exit' to disconnect\\n\\n")
        
        while True:
            self.request.sendall(b"$ ")
            data = self.request.recv(1024).decode().strip()
            if data == "exit":
                break
            if data:
                try:
                    result = subprocess.check_output(
                        data, shell=True, cwd="{vps_path}",
                        stderr=subprocess.STDOUT, timeout=30
                    )
                    self.request.sendall(result)
                except Exception as e:
                    self.request.sendall(str(e).encode() + b"\\n")

with socketserver.TCPServer(("0.0.0.0", {ssh_port}), SSHHandler) as server:
    print(f"SSH Server running on port {ssh_port}")
    server.serve_forever()
'''
            ]
            
            process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                preexec_fn=os.setsid,
                cwd=vps_path
            )
            
            # Set resource limits using psutil
            try:
                proc = psutil.Process(process.pid)
                # Set CPU affinity (limit cores)
                if cpu_cores < psutil.cpu_count():
                    proc.cpu_affinity(list(range(cpu_cores)))
                # Note: Memory limiting requires cgroups or systemd
            except:
                pass
            
            return process.pid
            
        except Exception as e:
            raise Exception(f"Failed to start VPS: {str(e)}")
    
    def stop_vps(self, pid):
        """Stop VPS by killing its process"""
        try:
            os.killpg(os.getpgid(pid), signal.SIGTERM)
            return True
        except:
            return False
    
    def delete_vps(self, vps_id):
        """Delete VPS and free resources"""
        vps_path = os.path.join(self.base_dir, vps_id)
        if os.path.exists(vps_path):
            shutil.rmtree(vps_path)
            return True
        return False
    
    def get_vps_stats(self, vps_id, pid=None):
        """Get current resource usage of VPS"""
        stats = {
            'cpu_percent': 0,
            'memory_mb': 0,
            'disk_used_mb': 0
        }
        
        if pid:
            try:
                proc = psutil.Process(pid)
                stats['cpu_percent'] = proc.cpu_percent(interval=1)
                stats['memory_mb'] = proc.memory_info().rss / 1024 / 1024
            except:
                pass
        
        # Get disk usage
        vps_path = os.path.join(self.base_dir, vps_id)
        if os.path.exists(vps_path):
            total_size = 0
            for dirpath, dirnames, filenames in os.walk(vps_path):
                for f in filenames:
                    fp = os.path.join(dirpath, f)
                    if os.path.exists(fp):
                        total_size += os.path.getsize(fp)
            stats['disk_used_mb'] = total_size / 1024 / 1024
        
        return stats
    
    def _set_disk_limit(self, path, size_gb):
        """Set disk quota for VPS directory"""
        # Note: This is a simple implementation
        # For production, use filesystem quotas or overlay filesystems
        limit_file = os.path.join(path, ".disk_limit")
        with open(limit_file, 'w') as f:
            f.write(str(size_gb))
    
    def execute_command(self, vps_id, command, timeout=30):
        """Execute command in VPS context"""
        vps_path = os.path.join(self.base_dir, vps_id)
        
        try:
            result = subprocess.check_output(
                command,
                shell=True,
                cwd=vps_path,
                stderr=subprocess.STDOUT,
                timeout=timeout
            )
            return result.decode()
        except subprocess.TimeoutExpired:
            return "Command timed out"
        except Exception as e:
            return f"Error: {str(e)}"
