# Add these commands to main.py (append at the end before bot.run())

@bot.command(name='vpsresources')
async def vps_resources(ctx, vps_id: str):
    """Check VPS resource usage"""
    if vps_id not in vps_storage:
        embed = create_embed("❌ Error", f"VPS with ID `{vps_id}` not found!", 0xff0000)
        await ctx.send(embed=embed)
        return
    
    vps = vps_storage[vps_id]
    
    if vps['owner_id'] != ctx.author.id and not is_admin(ctx.author.id):
        embed = create_embed("❌ Access Denied", "You don't have permission to view this VPS!", 0xff0000)
        await ctx.send(embed=embed)
        return
    
    # Get resource stats
    stats = vps_manager.get_vps_stats(vps_id, vps.get('process_id'))
    
    # Calculate percentages
    cpu_usage = stats['cpu_percent']
    ram_used = stats['memory_mb']
    ram_limit = vps['ram'] * 1024
    ram_percent = (ram_used / ram_limit * 100) if ram_limit > 0 else 0
    
    disk_used = stats['disk_used_mb']
    disk_limit = vps['disk'] * 1024
    disk_percent = (disk_used / disk_limit * 100) if disk_limit > 0 else 0
    
    embed = discord.Embed(
        title=f"📊 VPS Resources - {vps_id}",
        description="Current Resource Usage",
        color=0x3498db,
        timestamp=datetime.utcnow()
    )
    
    # CPU Usage Bar
    cpu_bar = create_progress_bar(cpu_usage, 100)
    embed.add_field(
        name=f"⚡ CPU Usage: {cpu_usage:.1f}%",
        value=f"{cpu_bar}\nLimit: {vps['cpu']} Cores",
        inline=False
    )
    
    # RAM Usage Bar
    ram_bar = create_progress_bar(ram_percent, 100)
    embed.add_field(
        name=f"💾 RAM Usage: {ram_percent:.1f}%",
        value=f"{ram_bar}\n{ram_used:.0f}MB / {ram_limit:.0f}MB",
        inline=False
    )
    
    # Disk Usage Bar
    disk_bar = create_progress_bar(disk_percent, 100)
    embed.add_field(
        name=f"💿 Disk Usage: {disk_percent:.1f}%",
        value=f"{disk_bar}\n{disk_used:.0f}MB / {disk_limit:.0f}MB",
        inline=False
    )
    
    status_emoji = "🟢" if vps['status'] == 'running' else "🔴"
    embed.add_field(name="📊 Status", value=f"{status_emoji} {vps['status'].capitalize()}", inline=True)
    
    embed.set_footer(text=f"Made by {config['bot_settings']['developer']}")
    await ctx.send(embed=embed)

def create_progress_bar(current, maximum, length=20):
    """Create a text-based progress bar"""
    if maximum == 0:
        return "█" * length
    
    filled = int((current / maximum) * length)
    filled = min(filled, length)
    
    bar = "█" * filled + "░" * (length - filled)
    return f"`{bar}`"

@bot.command(name='sshinfo')
async def ssh_info(ctx, vps_id: str):
    """Get SSH connection details"""
    if vps_id not in vps_storage:
        embed = create_embed("❌ Error", f"VPS with ID `{vps_id}` not found!", 0xff0000)
        await ctx.send(embed=embed)
        return
    
    vps = vps_storage[vps_id]
    
    if vps['owner_id'] != ctx.author.id and not is_admin(ctx.author.id):
        embed = create_embed("❌ Access Denied", "You don't have permission to view this VPS!", 0xff0000)
        await ctx.send(embed=embed)
        return
    
    embed = discord.Embed(
        title=f"🔐 SSH Connection Info - {vps_id}",
        description="Use these credentials to connect to your VPS",
        color=0x9b59b6,
        timestamp=datetime.utcnow()
    )
    
    # Get server IP (you need to set this)
    server_ip = "YOUR_SERVER_IP"  # Replace with actual server IP
    
    ssh_command = f"ssh root@{server_ip} -p {vps.get('ssh_port', 'N/A')}"
    
    embed.add_field(name="🌐 Server IP", value=f"`{server_ip}`", inline=True)
    embed.add_field(name="🔌 SSH Port", value=f"`{vps.get('ssh_port', 'N/A')}`", inline=True)
    embed.add_field(name="👤 Username", value="`root`", inline=True)
    embed.add_field(name="🔑 Password", value=f"`{vps.get('ssh_password', 'N/A')}`", inline=False)
    embed.add_field(name="📡 SSH Command", value=f"`{ssh_command}`", inline=False)
    
    # Alternative: Netcat connection
    nc_command = f"nc {server_ip} {vps.get('ssh_port', 'N/A')}"
    embed.add_field(name="🔧 Alternative (Netcat)", value=f"`{nc_command}`", inline=False)
    
    # Port forwarding example
    pf_example = f"ssh -L 8080:localhost:8080 root@{server_ip} -p {vps.get('ssh_port', 'N/A')}"
    embed.add_field(name="🔀 Port Forwarding Example", value=f"`{pf_example}`", inline=False)
    
    embed.add_field(
        name="📝 Notes",
        value="• Make sure VPS is running before connecting\n• Use port forwarding for web services\n• Contact admin if you can't connect",
        inline=False
    )
    
    embed.set_footer(text=f"Made by {config['bot_settings']['developer']}")
    await ctx.send(embed=embed)

@bot.command(name='execvps')
async def exec_vps(ctx, vps_id: str, *, command: str):
    """Admin only: Execute command in VPS"""
    if not is_admin(ctx.author.id):
        embed = create_embed("❌ Access Denied", "Only admins can use this command!", 0xff0000)
        await ctx.send(embed=embed)
        return
    
    if vps_id not in vps_storage:
        embed = create_embed("❌ Error", f"VPS with ID `{vps_id}` not found!", 0xff0000)
        await ctx.send(embed=embed)
        return
    
    vps = vps_storage[vps_id]
    
    processing = await ctx.send(embed=create_embed("⏳ Executing Command", f"Running: `{command}`", 0xffff00))
    
    try:
        result = vps_manager.execute_command(vps_id, command)
        
        # Limit output length
        if len(result) > 1900:
            result = result[:1900] + "\n... (output truncated)"
        
        embed = discord.Embed(
            title=f"✅ Command Executed - {vps_id}",
            description=f"**Command:** `{command}`",
            color=0x00ff00,
            timestamp=datetime.utcnow()
        )
        embed.add_field(name="📤 Output", value=f"```\n{result}\n```", inline=False)
        embed.set_footer(text=f"Made by {config['bot_settings']['developer']}")
        
        await processing.edit(embed=embed)
        
    except Exception as e:
        embed = create_embed("❌ Error", f"Failed to execute command: {str(e)}", 0xff0000)
        await processing.edit(embed=embed)

@bot.command(name='portforward')
async def port_forward(ctx, vps_id: str, local_port: int, remote_port: int):
    """Setup port forwarding for your VPS"""
    if vps_id not in vps_storage:
        embed = create_embed("❌ Error", f"VPS with ID `{vps_id}` not found!", 0xff0000)
        await ctx.send(embed=embed)
        return
    
    vps = vps_storage[vps_id]
    
    if vps['owner_id'] != ctx.author.id and not is_admin(ctx.author.id):
        embed = create_embed("❌ Access Denied", "You don't have permission to control this VPS!", 0xff0000)
        await ctx.send(embed=embed)
        return
    
    embed = discord.Embed(
        title=f"🔀 Port Forwarding Setup - {vps_id}",
        description="Configure port forwarding for your VPS",
        color=0x3498db,
        timestamp=datetime.utcnow()
    )
    
    server_ip = "YOUR_SERVER_IP"
    ssh_port = vps.get('ssh_port', 'N/A')
    
    # SSH Port Forwarding Command
    pf_command = f"ssh -L {local_port}:localhost:{remote_port} root@{server_ip} -p {ssh_port} -N"
    
    embed.add_field(name="📌 Local Port", value=f"`{local_port}`", inline=True)
    embed.add_field(name="📌 Remote Port", value=f"`{remote_port}`", inline=True)
    embed.add_field(name="🔌 SSH Port", value=f"`{ssh_port}`", inline=True)
    embed.add_field(name="📡 Command", value=f"```bash\n{pf_command}\n```", inline=False)
    
    embed.add_field(
        name="📝 Instructions",
        value=f"1. Run the command above in your terminal\n"
              f"2. Keep the terminal open\n"
              f"3. Access via `localhost:{local_port}`\n"
              f"4. Press Ctrl+C to stop forwarding",
        inline=False
    )
    
    embed.add_field(
        name="💡 Examples",
        value=f"• Web Server: Forward 8080 → 80\n"
              f"• Database: Forward 3307 → 3306\n"
              f"• SSH: Forward 2222 → 22",
        inline=False
    )
    
    embed.set_footer(text=f"Made by {config['bot_settings']['developer']}")
    await ctx.send(embed=embed)

@bot.command(name='vpsbackup')
async def vps_backup(ctx, vps_id: str):
    """Backup your VPS data"""
    if vps_id not in vps_storage:
        embed = create_embed("❌ Error", f"VPS with ID `{vps_id}` not found!", 0xff0000)
        await ctx.send(embed=embed)
        return
    
    vps = vps_storage[vps_id]
    
    if vps['owner_id'] != ctx.author.id and not is_admin(ctx.author.id):
        embed = create_embed("❌ Access Denied", "You don't have permission to backup this VPS!", 0xff0000)
        await ctx.send(embed=embed)
        return
    
    processing = await ctx.send(embed=create_embed("⏳ Creating Backup", "Backing up VPS data...", 0xffff00))
    
    try:
        import tarfile
        import time
        
        backup_name = f"vps_{vps_id}_backup_{int(time.time())}.tar.gz"
        backup_path = f"/tmp/{backup_name}"
        vps_path = f"/tmp/gvm_vps/{vps_id}"
        
        if os.path.exists(vps_path):
            with tarfile.open(backup_path, "w:gz") as tar:
                tar.add(vps_path, arcname=vps_id)
            
            # Get backup size
            backup_size = os.path.getsize(backup_path) / 1024 / 1024  # MB
            
            embed = create_embed(
                "✅ Backup Created",
                f"VPS `{vps_id}` has been backed up successfully!",
                0x00ff00
            )
            embed.add_field(name="📦 Backup File", value=f"`{backup_name}`", inline=True)
            embed.add_field(name="💾 Size", value=f"`{backup_size:.2f} MB`", inline=True)
            embed.add_field(name="📁 Location", value=f"`{backup_path}`", inline=False)
            embed.add_field(
                name="📝 Note",
                value="Download the backup file before it expires (24 hours)",
                inline=False
            )
            
            await processing.edit(embed=embed)
        else:
            embed = create_embed("❌ Error", "VPS data directory not found!", 0xff0000)
            await processing.edit(embed=embed)
            
    except Exception as e:
        embed = create_embed("❌ Error", f"Backup failed: {str(e)}", 0xff0000)
        await processing.edit(embed=embed)
